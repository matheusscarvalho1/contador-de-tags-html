const express = require('express');
const cheerio = require('cheerio');
const axios = require('axios');

const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req, res) => {
  res.sendFile('index.html', { root: __dirname });
});


app.post('/getTagCounts', async (req, res) => {
    try {
      const url = req.body.url;
      const response = await axios.get(url);
      const html = response.data;
      const $ = cheerio.load(html);
  
      const tags = {};
      $('*').each((i, element) => {
        const tagName = $(element).prop('tagName');
        if (tagName) {
          const normalizedTagName = tagName.toLowerCase();
          tags[normalizedTagName] = (tags[normalizedTagName] || 0) + 1;
        }
      });
  
      const tagCounts = Object.entries(tags).map(([tag, count]) => ({ tag, count }));
  
      res.send(tagCounts);
    } catch (error) {
      res.status(500).send('Error retrieving tag counts');
    }
  });
  
  app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });